// import './katakanaTranslator';

console.log('Content script loaded');
